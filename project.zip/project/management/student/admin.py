from django.contrib import admin

from student.models import *


# Register your models here.
admin.site.register(Student_details)
admin.site.register(Enroll_details)
admin.site.register(Callback)
